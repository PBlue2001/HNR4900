#include <string>

const int PORT {25565};
const int MSG_MAX_LEN {512};
const std::string ENDLINE {"\r\n"};
