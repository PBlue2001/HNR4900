#pragma once

#include <string>

const int CONNECTION_BACKLOG = 3;
const int PORT {25565};
const int MSG_MAX_LEN {512};
const std::string ENDLINE {"\r\n"};
