# termchat-core
A core library for common code for the termchat server and client
